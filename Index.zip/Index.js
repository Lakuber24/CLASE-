function calcularIMC() {
    const peso = parseFloat(document.getElementById('peso').value);
    const estatura = parseFloat(document.getElementById('estatura').value);


    if (!peso || !estatura || peso <= 0 || estatura <= 0) {
        Swal.fire({
            icon: 'warning',
            title: 'Datos incompletos',
            text: 'Por favor ingresa un peso y una estatura válidos.',
            confirmButtonColor: '#2a2420'
        });
        return;
    }


    const alturaM = estatura / 100;
    const imc = peso / (alturaM * alturaM);
    const imcStr = imc.toFixed(1);


    const box = document.getElementById('resultado');
    const valor = document.getElementById('valorIMC');
    const cat = document.getElementById('categoria');
    const comp = document.getElementById('composicion');


    box.className = 'result';
    box.style.display = 'block';
    valor.textContent = imcStr + ' kg/m²';


    if (imc < 18.5) {
        cat.textContent = 'Bajo peso';
        comp.textContent = 'Puede haber déficit de masa muscular o grasa corporal. Consulta a un profesional de la salud.';
        box.classList.add('naranja');

    } else if (imc < 25) {
        cat.textContent = 'Peso normal';
        comp.textContent = 'Tu composición corporal está dentro del rango saludable. ¡Sigue así!';
        box.classList.add('verde');

    } else if (imc < 30) {
        cat.textContent = 'Sobrepeso';
        comp.textContent = 'Existe un ligero exceso de peso respecto a tu altura. Pequeños cambios en hábitos pueden marcar la diferencia.';
        box.classList.add('naranja');
        Swal.fire({
            icon: 'info',
            title: 'Una señal a tiempo',
            text: 'A veces el cuerpo nos da señales suaves antes de que algo se vuelva un problema, y eso es una oportunidad.',
            confirmButtonColor: '#c47800',
            confirmButtonText: 'Entendido'
        });

    } else if (imc < 35) {
        cat.textContent = 'Obesidad tipo I';
        comp.textContent = 'Hay un exceso de grasa corporal que puede aumentar el riesgo cardiovascular. Se recomienda atención médica.';
        box.classList.add('rojo');
        mostrarMensajeObesidad();

    } else if (imc < 40) {
        cat.textContent = 'Obesidad tipo II';
        comp.textContent = 'Nivel elevado de grasa corporal con riesgo significativo. Es importante buscar apoyo médico y nutricional.';
        box.classList.add('rojo');
        mostrarMensajeObesidad();

    } else {
        cat.textContent = 'Obesidad tipo III (mórbida)';
        comp.textContent = 'Riesgo de salud muy alto. Se recomienda atención médica especializada de forma prioritaria.';
        box.classList.add('rojo');
        mostrarMensajeObesidad();
    }
}

function mostrarMensajeObesidad() {
    Swal.fire({
        title: 'Recuerda siempre',
        text: 'A veces el cuerpo nos da señales suaves antes de que algo se vuelva un problema, y eso es una oportunidad.',
        confirmButtonColor: '#a32d2d',
        confirmButtonText: 'Lo tendré presente'
    });
}